package com.ExpreefyIT.FeedbackByEmtion.classifiers.behaviors;

public interface ClassifyBehavior {
    float[][] classify(float[] input);
}
